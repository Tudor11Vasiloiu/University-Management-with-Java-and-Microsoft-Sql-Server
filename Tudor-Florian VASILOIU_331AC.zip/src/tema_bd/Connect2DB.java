package tema_bd;

import java.sql.*;

public class Connect2DB {
	
	 static public Connection conn;
     static public String dbURL = "jdbc:sqlserver://DESKTOP-2UA09L2\\SQLEXPRESS;databaseName=Universitate";
     static public String user = "sa";
     static public String pass = "Vasiloiu11Tudor";
     
	public static void Connect() {
		
		try {
        	conn = DriverManager.getConnection(dbURL, user, pass);
            if (conn != null) {
            	System.out.println("Conexiune realizata cu succes!\n");                
            }
 
        } catch (SQLException ex) {
        	System.out.println("Conexiune esuata!");
            ex.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
	}
	
	public static Connection getConn() {
		return conn;
	}
 	
    public static void main(String[] args) {
    	
       
        
        
    }
}